﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Biletoman.Properties;

namespace Biletoman
{
    public partial class Form1 : Form
    {
        Bitmap bmp;
        Bitmap oryginal;
        int a = 0; int b = 0; int koszt = 0;
        int minuty;
        int godziny;

        public Form1()
        {
            InitializeComponent();
        }

       
        public void text2cyfra(string a_tekst, int numer, int ogranicz)
        {
            try
            {
                int m = Int32.Parse(a_tekst);
                if (m > ogranicz)
                { throw new Exception("Za duża wartość"); }

                if (m < 0)
                { throw new Exception("Za mała wartość"); }

                switch (numer)
                {
                    case 1: trackBar1.Value = m; break;
                    case 2: trackBar2.Value = m; break;
                    case 3: trackBar3.Value = m; break;
                    case 4: trackBar4.Value = m; break;
                    case 5: trackBar5.Value = m; break;
                    case 6: czas(m); break;
                    case 7: koszt = m; button10.Enabled = true; break;
                    default: Console.WriteLine("Default case"); break;
                }
            }
            catch (Exception ex)
            { MessageBox.Show(ex.Message); }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            button3.Enabled = false;
            button4.Enabled = false;
            button5.Enabled = false;
            button6.Enabled = false;
            button7.Enabled = false;
            button8.Enabled = false;
            //button9.Enabled = false;
            button10.Enabled = false;
            pictureBox2.Image = Resources.instr;
        }

        public void aktywator()
        {
            button3.Enabled = true;
            button4.Enabled = true;
            button5.Enabled = true;
            button6.Enabled = true;
            button7.Enabled = true;
            //button8.Enabled = true;
           // button9.Enabled = true;
        }

        public void zab()
        {
            if (a == 1 && b == 1)
            { button8.Enabled = true; }
        }
  


        private void pictureBox1_Click(object sender, EventArgs e)
        { }

        private void textBox1_TextChanged(object sender, EventArgs e)
        { text2cyfra(textBox1.Text, 1, 31); }

        private void textBox2_TextChanged(object sender, EventArgs e)
        { text2cyfra(textBox2.Text, 2, 12); }

        private void textBox3_TextChanged(object sender, EventArgs e)
        { text2cyfra(textBox3.Text, 3, 2020); }

        private void textBox4_TextChanged(object sender, EventArgs e)
        { text2cyfra(textBox4.Text, 4, 24); }

        private void textBox5_TextChanged(object sender, EventArgs e)
        { text2cyfra(textBox5.Text, 5, 60); }


        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            trackBar1.Maximum = 31;
            trackBar1.TickFrequency = 2;
            trackBar1.LargeChange = 3;
            trackBar1.SmallChange = 1;
            textBox1.Text = "" + trackBar1.Value;

        }

        private void trackBar2_Scroll(object sender, EventArgs e)
        {
            trackBar2.Maximum = 12;
            trackBar2.TickFrequency = 2;
            trackBar2.LargeChange = 2;
            trackBar2.SmallChange = 1;
            textBox2.Text = "" + trackBar2.Value;
        }

        private void trackBar3_Scroll(object sender, EventArgs e)
        {
            trackBar3.Minimum = 2015;
            trackBar3.Maximum = 2020;
            trackBar3.TickFrequency = 1;
            trackBar3.LargeChange = 1;
            trackBar3.SmallChange = 1;
            textBox3.Text = "" + trackBar3.Value;
        }

        private void trackBar4_Scroll(object sender, EventArgs e)
        {
            trackBar4.Maximum = 24;
            trackBar4.TickFrequency = 1;
            trackBar4.LargeChange = 1;
            trackBar4.SmallChange = 1;
            textBox4.Text = "" + trackBar4.Value;
        }

        private void trackBar5_Scroll(object sender, EventArgs e)
        {
            trackBar5.Maximum = 60;
            trackBar5.TickFrequency = 1;
            trackBar5.LargeChange = 5;
            trackBar5.SmallChange = 1;
            textBox5.Text = "" + trackBar5.Value;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            hiphop(trackBar1.Value, 36, 846, 90, 846);
            hiphop_male(trackBar1.Value, 346, 1126, 373, 1126);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            hiphop(trackBar2.Value, 180, 846, 227, 846);
            hiphop_male(trackBar2.Value, 418, 1126, 441, 1126);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (trackBar3.Value == 2016)
            { funk(Resources._2016, 512, 1128); }
            if (trackBar3.Value == 2017)
            { funk(Resources._2016, 512, 1128); }
        }

        private void button6_Click(object sender, EventArgs e)//godzina
        {
            hiphop(trackBar4.Value, 374, 846, 416, 846);
            a = 1;
            zab();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            hiphop(trackBar5.Value, 517, 846, 557, 846);
            b = 1;
            zab();
        }

        public void funk(Bitmap bmp22, int xlab, int ylab)
        {
            Color p;
            int width = bmp22.Width;
            int height = bmp22.Height;
            for (int y = 0; y < height; y++)
            {
                for (int x = 0; x < width; x++)
                {
                    p = bmp22.GetPixel(x, y);
                    int a = p.A;
                    int r = p.R;
                    int g = p.G;
                    int b = p.B;
                    bmp.SetPixel(x + xlab, y + ylab, Color.FromArgb(a, r, g, b));
                }
            }
            pictureBox1.Image = bmp;
        }

        public void czas(int t)
        {
            int godz = trackBar4.Value; //Int32.Parse(textBox4.Text);
            int min = trackBar5.Value;// Int32.Parse(textBox5.Text); 
            int a = ((godz * 60) + min) - t;
            minuty = a % 60;
            godziny = (a - minuty) / 60;
        }



        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true)
            {
                bmp = Resources.czysto;
                pictureBox1.Image = bmp;
                aktywator();
            }
            else { }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            hiphop_male(godziny, 347, 1176, 369, 1176);
            hiphop_male(minuty, 418, 1176, 440, 1176);
        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {
            text2cyfra(textBox6.Text, 6, 1000);
        }

        public void hiphop(int track, int x1, int y1, int x2, int y2)
        {
            int cyfrB = track % 10;
            int cyfrA = (track - (track % 10)) / 10;
            switch (cyfrA)
            {
                case 0: funk(Resources._0, x1, y1); break;
                //case 1: funk(Resources._1, x1, y1); break;
                case 2: funk(Resources._2, x1, y1); break;
                //case 3: funk(Resources._3, x1, y1); break;
                // case 4: funk(Resources._4, x1, y1); break;
                // case 5: funk(Resources._5, x1, y1); break;
                case 6: funk(Resources._6, x1, y1); break;
                //case 7: funk(Resources._7, x1, y1); break;
                //case 8: funk(Resources._8, x1, y1); break;
                case 9: funk(Resources._9, x1, y1); break;
            }
            switch (cyfrB)
            {
                case 0: funk(Resources._0, x2, y2); break;
               // case 1: funk(Resources._1, x2, y2); break;
                case 2: funk(Resources._2, x2, y2); break;
               // case 3: funk(Resources._3, x2, y2); break;
                // case 4: funk(Resources._4, x2, y2); break;
                // case 5: funk(Resources._5, x2, y2); break;
                case 6: funk(Resources._6, x2, y2); break;
                //case 7: funk(Resources._7, x2, y2); break;
                //case 8: funk(Resources._8, x2, y2); break;
                case 9: funk(Resources._9, x2, y2); break;
            }
        }

        public void hiphop_male(int track, int x1, int y1, int x2, int y2)
        {
            int cyfrB = track % 10;
            int cyfrA = (track - (track % 10)) / 10;

            switch (cyfrA)
            {
                case 9: funk(Resources.m9, x1, y1); break;
                case 8: funk(Resources.m8, x1, y1); break;
                case 7: funk(Resources.m7, x1, y1); break;
                case 6: funk(Resources.m6, x1, y1); break;
                case 5: funk(Resources.m5, x1, y1); break;
                case 4: funk(Resources.m4, x1, y1); break;
                case 3: funk(Resources.m3, x1, y1); break;
                case 2: funk(Resources.m2, x1, y1); break;
                case 1: funk(Resources.m1, x1, y1); break;
                case 0: funk(Resources.m0, x1, y1); break;
            }

            switch (cyfrB)
            {
                case 9: funk(Resources.m9, x2, y2); break;
                case 8: funk(Resources.m8, x2, y2); break;
                case 7: funk(Resources.m7, x2, y2); break;
                case 6: funk(Resources.m6, x2, y2); break;
                case 5: funk(Resources.m5, x2, y2); break;
                case 4: funk(Resources.m4, x2, y2); break;
                case 3: funk(Resources.m3, x2, y2); break;
                case 2: funk(Resources.m2, x2, y2); break;
                case 1: funk(Resources.m1, x2, y2); break;
                case 0: funk(Resources.m0, x2, y2); break;
            }
        }

       
        private void pictureBox2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("1) zaznacz <Szablon> by rozpocząć, aby zresetować szablon odznacz i zaznacz ponownie. 2) wybierz dzień, miesiać, rok. 3)Określ koniec postoju i czas trwania postoju. 4) wciśnij przyciski 5) nie dziala dla dużych cyfr: 4,5,7,8");

        }

        private void button10_Click(object sender, EventArgs e)
        {
            int grosze = koszt % 100;
            int zlotowy = (koszt - grosze) / 100;
            hiphop_male(zlotowy, 417, 1078, 442, 1078);
            hiphop_male(grosze, 487, 1078, 512, 1078);
        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {
            text2cyfra(textBox7.Text, 7, 1000);
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                OpenFileDialog ofd = new OpenFileDialog();
                if (ofd.ShowDialog() != System.Windows.Forms.DialogResult.OK) return;
                bmp = new Bitmap(ofd.FileName);
                oryginal = new Bitmap(ofd.FileName);

                if (bmp.Width >= 3000 | bmp.Height >= 3000)
                    throw new Exception("Za duża szerokość lub wysokość, max 3200 x 3200");

                if (bmp.Height <= 50 | bmp.Width <= 50)
                    throw new Exception("Za mały, min 50 x 50");
                pictureBox1.Image = bmp;
                aktywator();

            }
            catch (Exception ex)
            { MessageBox.Show(ex.Message); }
        }

        private void backgroundColorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ColorDialog MyColor = new ColorDialog();
            if (MyColor.ShowDialog() == DialogResult.OK)
                BackColor = MyColor.Color;
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (pictureBox1 != null)
            {
                SaveFileDialog save = new SaveFileDialog();
                if (save.ShowDialog() != System.Windows.Forms.DialogResult.OK) return;
                pictureBox1.Image.Save(save.FileName);

            }
        }

        private void button9_Click(object sender, EventArgs e)
        {

        }

        private void button8_Click_1(object sender, EventArgs e)
        {
            text2cyfra(textBox6.Text, 6, 1000);
        }

        private void textBox4_TextChanged_1(object sender, EventArgs e)
        {

        }
    }
}
